Goomy Clicker
=============

The "original" Pokémon-themed ~~ripoff~~ ~~me-too game~~ inspired spinoff of Cookie Clicker, now on Github for everybody to contribute to.


License
-------

The Goomy Clicker code is licensed under the GNU Affero GPL v3.
